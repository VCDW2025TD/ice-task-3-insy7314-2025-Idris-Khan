// src/app.js
const express = require("express");
const helmet = require("helmet");

const app = express();

// Parse JSON + CSP violation reports
app.use(express.json({ type: ["application/json", "application/csp-report"] }));

// Baseline Helmet headers
app.use(helmet());

// Content Security Policy
const cspDirectives = {
  defaultSrc: ["'self'"],
  scriptSrc: ["'self'"],   // no inline scripts, no external CDNs
  styleSrc: ["'self'"],    // no external stylesheets
  imgSrc: ["'self'"],      // images must come from our server
  connectSrc: ["'self'"],  // fetch/XHR/WebSocket only to backend
  frameAncestors: ["'none'"], // disallow iframe embedding
  upgradeInsecureRequests: [] // auto-upgrade http->https
};

app.use(
  helmet.contentSecurityPolicy({
    useDefaults: true,
    directives: {
      ...cspDirectives,
      "report-uri": ["/csp-report"], // browser sends violation reports here
    },
    reportOnly: process.env.NODE_ENV !== "production", // log-only in dev
  })
);

// Collect violation reports
app.post("/csp-report", (req, res) => {
  console.log("🚨 CSP Violation:", JSON.stringify(req.body, null, 2));
  res.sendStatus(204);
});

// Example health check
app.get("/api/health", (_req, res) => res.json({ ok: true, ts: new Date() }));

module.exports = app;
